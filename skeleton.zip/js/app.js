/**
 * Presto app skeleton
 * @param {Presto App} app [description]
 *
 * Sample.Hello should be replaced with something that makes sense for your project
 * Make sure it is changed in this file as well as in the App.xml file jsclass property
 */
Sample.Hello = function( app ) {
	
	// Entry method
	this.onLoad = function() {
		
	};
	
};