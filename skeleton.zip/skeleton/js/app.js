Sample.Hello = function( app ) {
	
	// Entry method
	this.onLoad = function() {
		
	};
	
};