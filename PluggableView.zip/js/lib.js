/**
 * Pluggable View Class
 * @param  {Object} $ jQuery Object
 */
(function($) {
 
  /**
   * Step 1: Store id for view. Should be the same name as the root folder for the view.
   */
  var id = "PluggableView";

  Presto.namespace("Sample.view");
 
  /**
   * Step 2: Create class name
   * Pluggable View Class implementation
   * @param  {DOM Node} selector  Identifies the view container - the node in the containing app or page where this view will be rendered.  
   * @param  {Object} dataTable Data model containing the Mashup/Mashable data
   * @param  {[Object]} config    Configuration properties for this view with this mashable or mashup. This is the configuration that users set when they add views or edit them in Presto Hub.
   */
  Sample.view.myPluggableView = function(selector, dataTable, config) {

    //Enable Browser console debugging
    Presto.Console(true);

    config = config || {};
    
    var me = this,
        el = $(selector);
        me.config = config;

    /**
     * Step 3: Create markup displayed when the user edits the View.
     */
    me.showConfig = function() {};

    /**
     * Step 4: Create validation rules for the View Wizard if it applies.
     * This method is used by the View Wizard in Presto, if true the View creation process will continue
     */
    me.validate = function() {
      return true;
    };

    /**
     * Step 5: Specify from which fields, the view will get its static data
     */
    me.getConfig = function() {
      return config;
    };

    /**
     * Step 6: Create Draw markup.
     * This renders the View. This is where view and dynamic data come together.
     */
    me.draw = function() {};


    /**
     * Step 7: Optional. Create markup to be drawn when data is updated.
     * Called when the dataTable has been updated
     */
    me.update = function () {};
  };
 
  /**
   * View Registration
   * cls 
   * @type {[type]}
   */
  Presto.view.register({ 
    cls: Sample.view.myPluggableView,
    lib: id
  });
}( jQuery ));